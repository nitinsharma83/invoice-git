<h1 class="text-white">Welcome to <?php echo $_settings->info('name') ?></h1>
<hr>
<section class="content">
    <div class="container-fluid">
    <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><a  href="<?php echo base_url ?>admin/?page=invoice" class="fas fa-file-invoice"></a></span>
              <div class="info-box-content">
                <a href="<?php echo base_url ?>admin/?page=invoice" style=" text-decoration: none;  color:white;" class="info-box-text;">Invoices</a>
                <span class="info-box-number">
                  <?php echo number_format($conn->query("SELECT * FROM invoice_list")->num_rows) ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-primary elevation-1"><a href="<?php echo base_url ?>admin/?page=proformainvoice" class="fas fa-file-invoice"></a></span>
              <div class="info-box-content">
              <a href="<?php echo base_url ?>admin/?page=proformainvoice" style=" text-decoration: none;  color:white;" class="info-box-text;">Profo. Inv.</a>
                <span class="info-box-number"> <?php echo number_format($conn->query("SELECT * FROM proformainvoice_list")->num_rows) ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-primary elevation-1"><a href="<?php echo base_url ?>admin/?page=category" class="fas fa-th-list"></a></span>
              <div class="info-box-content">
              <a href="<?php echo base_url ?>admin/?page=category" style=" text-decoration: none;  color:white;" class="info-box-text;">Category</a>                
                <span class="info-box-number"> <?php echo number_format($conn->query("SELECT * FROM category_list")->num_rows) ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><a href="<?php echo base_url ?>admin/?page=product" class="fas fa-box"></a></span>

              <div class="info-box-content">
              <a href="<?php echo base_url ?>admin/?page=product" style=" text-decoration: none;  color:white;" class="info-box-text;">Products</a>                
                <span class="info-box-number"><?php echo number_format($conn->query("SELECT * FROM product_list")->num_rows) ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><a href="<?php echo base_url ?>admin/?page=service" class="fas fa-hands-helping"></a></span>

              <div class="info-box-content">
              <a href="<?php echo base_url ?>admin/?page=service" style=" text-decoration: none;  color:white;" class="info-box-text;">Services</a>                                
                <span class="info-box-number"><?php echo number_format($conn->query("SELECT * FROM service_list")->num_rows) ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
    </div>
</section>
