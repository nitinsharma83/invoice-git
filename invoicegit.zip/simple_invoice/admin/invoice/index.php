<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>
<div class="card card-outline card-primary">
	<div class="card-header">
		<h3 class="card-title">List of Invoices</h3>
		<div class="card-tools">
			<a href="./?page=invoice/manage" class="btn btn-flat btn-primary"><span class="fas fa-plus"></span>  Create New</a>
		</div>
	</div>
	<div class="card-body">
		<div class="container-fluid">
        <div class="container-fluid">
			<table class="table table-bordered table-stripped">
				<colgroup>
					<col width="5%">
					<col width="13%">
					<col width="10%">
					<col width="15%">
					<col width="20%">
					<col width="25%">
				</colgroup>
				<thead>
					<tr>
						<th>S.No.</th>
						<th>Date Created</th>
						<th>Invoice Code</th>
						<th>Cust. Name</th>
						<th>Comp. Name</th>
						<th>Details</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$i = 1;
						$qry = $conn->query("SELECT * from `invoice_list`  order by date(date_created) desc ");
						while($row = $qry->fetch_assoc()):
                            $row['remarks'] = strip_tags(stripslashes(html_entity_decode($row['remarks'])));
							$items = $conn->query("SELECT * FROM invoices_items where invoice_id = {$row['id']} ")->num_rows;
					?>
						<tr>
							<td class="text-center"><?php echo $i++; ?></td>
							<td><?php echo date("Y-m-d H:i",strtotime($row['date_created'])) ?></td>
							<td><?php echo $row['invoice_code'] ?></td>
							<td><?php echo $row['customer_name'] ?></td>
							<td><?php echo $row['company_name'] ?></td>
							<td>
								<p class="m-0"><small><b>Invoice Type:</b><?php echo $row['type'] == 1 ? "Product":"Service" ?></small></p>
								<p class="m-0"><small><b>Item Count:</b> <?php echo number_format($items) ?></small></p>
								<p class="m-0"><small><b>Total Amount:</b><?php echo number_format($row['total_amount']) ?></small></p>
							</td>
							<td align="center">
								 <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
				                  		Action
				                    <span class="sr-only">Toggle Dropdown</span>
				                  </button>
				                  <div class="dropdown-menu" role="menu">
								  <a class="dropdown-item edit_data" href="./?page=invoice/view&id=<?php echo md5($row['id']) ?>"><span class="fa fa-eye text-smooth"></span> View</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item edit_data" href="./?page=invoice/manage&id=<?php echo md5($row['id']) ?>"><span class="fa fa-edit text-primary"></span>Edit & Print</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-trash text-danger"></span> Delete</a>									
								  </div>
							</td>
						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){
		$('.delete_data').click(function(){
			_conf("Are you sure to delete this invoice permanently?","delete_invoice",[$(this).attr('data-id')])
		})
		$('.table').dataTable();
		$('#uni_modal').on('shown.bs.modal', function() {
			$('.select2').select2({width:'resolve'})
			$('.summernote').summernote({
				height: 200,
				toolbar: [
					[ 'style', [ 'style' ] ],
					[ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
					[ 'fontname', [ 'fontname' ] ],
					[ 'fontsize', [ 'fontsize' ] ],
					[ 'color', [ 'color' ] ],
					[ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
					[ 'table', [ 'table' ] ],
					[ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
				]
			})
		})
	})
	function delete_invoice($id){
		start_loader();
		$.ajax({
			url:_base_url_+"classes/Master.php?f=delete_invoice",
			method:"POST",
			data:{id: $id},
			dataType:"json",
			error:err=>{
				console.log(err)
				alert_toast("An error occured.",'error');
				end_loader();
			},
			success:function(resp){
				if(typeof resp== 'object' && resp.status == 'success'){
					location.reload();
				}else{
					alert_toast("An error occured.",'error');
					end_loader();
				}
			}
		})
	}

</script>
<script type="text/javascript"> 
$(document).ready(function () { 
    //Disable full page 
    $('body').bind('cut copy paste', function (e) { 
        e.preventDefault(); 
    }); 
     
    //Disable part of page 
    $('#id').bind('cut copy paste', function (e) { 
        e.preventDefault(); 
    }); 
}); 
$(document).ready(function () { 
    //Disable full page 
    $('body').bind('cut copy paste', function (e) { 
        e.preventDefault(); 
    }); 
     
    //Disable part of page 
    $('#id').bind('cut copy paste', function (e) { 
        e.preventDefault(); 
    }); 
}); 
$(document).ready(function () { 
    //Disable cut copy paste 
    $('body').bind('cut copy paste', function (e) { 
        e.preventDefault(); 
    }); 
    
    //Disable mouse right click 
    $("body").on("contextmenu",function(e){ 
        return false; 
    }); 
}); 
</script> 
<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>
<?php
$type = isset($_GET['type']) ? $_GET['type'] : 1 ;
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `invoice_list` where md5(id) = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v;
        }
    }
}
$tax_rate = isset($tax_rate) ? $tax_rate : $_settings->info('tax_rate');
$item_arr = array();
if(isset($id)){
if($type == 1)
	$items = $conn->query("SELECT i.*,p.description,p.id as `pid`,p.`product` as `name`,p.category_id as cid FROM invoices_items i inner join product_list p on p.id = i.form_id where i.invoice_id = '{$id}' ");
else
	$items = $conn->query("SELECT i.*,s.description,s.id as `sid`,s.`service` as `name`,s.category_id as cid FROM invoices_items i inner join service_list s on s.id = i.form_id where i.invoice_id = '{$id}' ");
while($row=$items->fetch_assoc()):
	$category = $conn->query("SELECT * FROM `category_list` where id = {$row['cid']}");
	$cat_count = $category->num_rows;
	$res = $cat_count > 0 ? $category->fetch_assoc(): array();
	$row['cat_name'] = $cat_count > 0 ? $res['name'] : "N/A";
	$row['description'] = stripslashes(html_entity_decode($row['description']));
	$item_arr[] = $row;
endwhile;
}
?>
<style>
#item-list th, #item-list td{
	padding:5px 3px!important;
}
</style>