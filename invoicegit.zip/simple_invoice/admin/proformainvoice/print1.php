<?php 
require ('../../config.php');
?>
<!DOCTYPE html>
<html lang="en">
<?php include "../inc/header.php" ?>
<body>
<?php
$type = isset($_GET['type']) ? $_GET['type'] : 1 ;
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `proformainvoice_list` where id = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v;
        }
    }
}
$tax_rate = isset($tax_rate) ? $tax_rate : $_settings->info('tax_rate');
?>
<style>
table th, table td{
    padding:5px 3px!important;
}
</style>
<div>
    <div style="width: 100% align-content: space-between; display: flex;">
        <p style="width: 50%; padding-left: 20px; font-size: 20px; color:white; background-color:darkslategray;";><b><i class="far fa-calendar-check">&nbsp;Invoice Date:</i></b> <?php echo date("F d, Y",strtotime($date_created)) ?></p>
        <p style="width: 50%; padding-left: 200px; font-size: 20px; color:#171717;"><b><i style="color: #171717;"><b><i class="far fa-edit">&nbsp;Invoice Code:</i></b> <?php echo $invoice_code ?></p>
    </div>
    <div style="width: 100%; display: flex;">
        <div style="width: 40%">
            <img src="https://www.itsolution4india.com/assets/images/logo.png" style="align-items: center; padding-bottom: 20px; padding-left: 10px;">
        </div style="width: 60%; font-size: 50px;">
            <h1 style="color:#171717; font-size: 50px; letter-spacing: 3px; text-decoration: underline dotted #171717; padding-left: 70px;"><b>PROFORMA INVOICE</b></h1>

        </div>
    </div>
        <div style="display: flex;">
        <div style="width: 50%; color:#171717; font-size: 20px;" class="sender">
            <p><b><u>Bill From:</u> </b><span style="font-weight: 500">IT Solutions 4 India <br>1/1 3rd Floor Above Vishal</span><br>
            <span style="font-weight: 500" >Mega Mart Tilak Nagar</span><br>
            <span style="font-weight: 500">Delhi -110018</span></p>
            <p><b><u>GST No:</u> </b><span style="font-weight: 500">07KQTPS5747F1ZV</span></p>
        </div>
        <div  style="width: 50%; font-size: 20px; color:#171717; margin-left: 130px;" class="receiver"> 
            <p><b><u>Bill To:</u></b><span style="font-weight: 500"> <?php echo $customer_name ?></span></p>
            <p><b><u>Company:</u></b><span style="font-weight: 500"> <?php echo $company_name ?></span></p>
            <p><b><u>Address:</u></b><span style="font-weight: 500"> <?php echo $customer_address ?></span></p>
            <p><b><u>GST No.:</u></b><span style="font-weight: 500"> <?php echo $gst_number ?></span></p>
        </div>
    </div>
    <hr>
    <table style="font-size: 22px; border: 2px solid #171717;" class="table table-bordered">
        <colgroup>
            <col width="10%">
            <col width="15%">
            <col width="35%">
            <col width="15%">
            <col width="15%">
        </colgroup>
        <thead>
            <tr style="font-size: 22px; border: 2px solid #171717; color:black;">
                <th style="font-size: 20px;  background-color:#95b3e8;" class="text-center">QTY</th>
                <th style="font-size: 20px;" class="text-center">UNIT</th>
                <th style="font-size: 20px;" class="text-center">Product/Service</th>
                <th style="font-size: 20px;" class="text-center">Cost</th>
                <th style="font-size: 20px;" class="text-center">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if($type == 1)
                $items = $conn->query("SELECT i.*,p.description,p.id as pid,p.product as `name`,p.category_id as cid FROM proformainvoices_items i inner join product_list p on p.id = i.form_id where i.invoice_id = '{$id}' ");
            else
                $items = $conn->query("SELECT i.*,s.description,s.id as `sid`,s.`service` as `name`,s.category_id as cid FROM proformainvoices_items i inner join service_list s on s.id = i.form_id where i.invoice_id = '{$id}' ");
            while($row=$items->fetch_assoc()):
                $category = $conn->query("SELECT * FROM `category_list` where id = {$row['cid']}");
                $cat_count = $category->num_rows;
                $res = $cat_count > 0 ? $category->fetch_assoc(): array();
                $cat_name = $cat_count > 0 ? $res['name'] : "N/A";
                $description = stripslashes(html_entity_decode($row['description']));
            ?>
            <tr style="font-size: 22px; border: 2px solid #171717;">
                <td style="font-size: 22px; border: 2px solid #171717;" class="text-center"><?php echo $row['quantity'] ?></td>
                <td style="font-size: 22px; border: 2px solid #171717;" class="text-center"><?php echo $row['unit'] ?></td>
                <td style="font-size: 22px; border: 2px solid #171717;" class="text-center">
                <p style="font-size: 22px;" class="m-0"><small><b>Category:</b> <?php echo $cat_name ?></small></p>
                <p style="font-size: 22px;" class="m-0"><small><b>Name:</b> <?php echo $row['name'] ?></small></p>
                <div>
                    <?php echo $description ?>
                </div>
                </td>
                <td style="font-size: 22px;" class="text-right"><?php echo number_format($row['price']) ?></td>
                <td style="font-size: 22px;" class="text-right"><?php echo number_format($row['total']) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr class="bg-foot" style="background-color:#95b3e8 !important; border: 2px solid #171717;">
                <th class="text-right" colspan="4">Sub Total</th>
                <th class="text-right" id="sub_total"><?php echo number_format($sub_total) ?></th>
            </tr>
            <tr class="bg-foot" style="background-color:#95b3e8 !important; border: 2px solid #171717;">
                <th class="text-right" colspan="4">Tax Rate</th>
                <th class="text-right" id="tax_rate"><?php echo $tax_rate ?>%</th>
            </tr>
            <tr class="bg-foot" style="background-color:#95b3e8 !important; border: 2px solid #171717;">
                <th class="text-right" colspan="4">Tax</th>
            <th class="text-right" id="tax"><?php echo number_format($sub_total * ($tax_rate/100) ) ?></th>
            </tr>
                <tr class="bg-foot" style="background-color:#95b3e8 !important; border: 2px solid #171717;">
                <th class="text-right" colspan="4">Grand Total</th>
                <th class="text-right" id="gtotal"><?php echo number_format($total_amount) ?></th>
            </tr>
        </tfoot>
</table>
<hr>
<h5 style="color:#171717;"><b><u>Remarks:</u></b>
<?php echo $remarks ?>
            </h5>
<div style="width: 100%; display: flex; padding-top: 70px; color:#171717;">
    <div style="width: 50%;">
    <hr style="border-top: 3px dashed #171717;">
    <h4 style="padding-left: 130px; background-color: lightgrey; color:#171717;"><u><b>BANK DETAILS</b></u></h4>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>BANK NAME: </b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">ICICI BANK LTD</h5>
    </div>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>COMPANY NAME: </b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">IT SOLUTION 4 INDIA</h5>
    </div>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>ACCOUNT NUMBER: </b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">100505501217</h5>
    </div>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>IFSC CODE: </b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">ICIC0001005</h5>
    </div>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>PAN CARD NUMBER:</b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">KQTPS5747F</h5>
    </div>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>SAC CODE: </b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">998361</h5>
    </div>
    <div style="display: flex;">
        <h5 style="width: 50%; color:#171717;"><b>STATE GST CODE: </b></h5>
        <h5 style="width: 50%; color:#171717; font-weight:600;">07, DELHI</h5>
    </div>
    <hr style="border-top: 3px dashed #171717;">
    </div>
    <div>
        
    </div>
</div>
<div style="width: 50%; padding-top: 130px; color:#171717;">
        <h5 style="border: 2px solid black; border-radius: 5px; padding: 12px; background-color: lightgrey;">This is a computer generated Invoice and does not require Signature/Stamp.</h5>
    </div>
<div style="width: 100%; margin-top: 40px; margin-top: 30px; color:#171717;">
        <h6 style="border: 2px solid black; border-radius: 5px; padding: 7px; font-size: 18px;">NOTE: This Proforma Invoice shall be aplicable for a period of 30 days and customer don't have a right to claim on GST portal.</h6>
    </div>

<div style="display: flex; width: 100%; color:#171717;">
    <h3 style="width: 50%; color:white; background-color:darkslategray;"><i class="fa fa-phone">Contact Us: 9711347474</i></h3>
    <h3 style="width: 50%; padding-left: 170px; background-color: lightgrey;"><i class="fa fa-envelope">www.itsolution4india.com</i></h3>
</div>
</body>
</html>